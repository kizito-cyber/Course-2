﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControllerX : MonoBehaviour
{
    public GameObject dogPrefab;
    private float waitSpawn = 0f;
    public bool isSpawned = false;
    public int bePatient = 0;


    // Update is called once per frame
    void Update()
    {

        // On spacebar press, send dog
        if (Input.GetKeyDown(KeyCode.Space)&& isSpawned == false)
        {
            Instantiate(dogPrefab, transform.position, dogPrefab.transform.rotation);
            isSpawned = true;
            waitSpawn = 3.0f;
        }

        if(isSpawned==true)
        {
            waitSpawn -= Time.deltaTime * 1;
            bePatient = (int)waitSpawn;
        }
        if (bePatient == 0)
        {
            isSpawned = false;
        }
    }
}